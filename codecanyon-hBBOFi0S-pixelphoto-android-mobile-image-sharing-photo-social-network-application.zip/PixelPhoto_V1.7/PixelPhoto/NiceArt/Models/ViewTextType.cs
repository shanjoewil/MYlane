﻿namespace PixelPhoto.NiceArt.Models
{
    public enum ViewTextType
    {
        Add,
        Change,
    }
}