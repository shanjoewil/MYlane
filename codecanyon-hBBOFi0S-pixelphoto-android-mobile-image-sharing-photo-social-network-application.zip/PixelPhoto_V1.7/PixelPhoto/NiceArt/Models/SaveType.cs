﻿namespace PixelPhoto.NiceArt.Models
{
    public enum SaveType
    {
        Normal,
        Filter,
    }
}